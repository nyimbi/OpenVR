INSERT INTO logs (title, created) VALUES ("Testing Patching", NOW());
/*
ALTER TABLE registrations ADD PRIMARY KEY (`id`);
ALTER TABLE fp_fingerprints ADD PRIMARY KEY (`id`);
*/


