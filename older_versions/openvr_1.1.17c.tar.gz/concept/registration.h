#ifndef REGISTRATION_H
#define REGISTRATION_H
#include <QDialog>
#include <QObject>

class registration : public QDialog
{
public:
    registration();
};

#endif // REGISTRATION_H
