 #include <QtGui>
#include "registration.h"
#include "ui_registration_dialog.h"

registration::registration()
{




}
