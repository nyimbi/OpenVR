#!/bin/bash


echo "Jesus is Lord"
