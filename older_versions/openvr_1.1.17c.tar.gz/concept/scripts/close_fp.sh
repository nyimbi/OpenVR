#!/bin/sh
killall enroll 2>&-;
#bin/closeFp;

