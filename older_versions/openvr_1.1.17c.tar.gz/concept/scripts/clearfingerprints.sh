#!/bin/bash

rm -f templates/*
