 var data_validation = '{"fb-submit-button":{"hover":{"background-image":""}},"item2_text_1":{},"item3_password_1":{"minlength":5}}';
 var data_jsplugins = '[]';
 var data_cssplugins = '[]';