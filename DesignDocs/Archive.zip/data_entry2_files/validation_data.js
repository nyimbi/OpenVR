 var data_validation = '{"fb-submit-button":{"hover":{"background-image":""}},"item22_text_1":{}}';
 var data_jsplugins = '[]';
 var data_cssplugins = '[]';