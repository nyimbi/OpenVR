#!/bin/bash
echo `df -h /opt |tr -d "\%"`
