authorizedScript=1;	

