#!/bin/bash 


if [ "$1" ]; then
	tar xf "$1" /opt/openvr
fi
