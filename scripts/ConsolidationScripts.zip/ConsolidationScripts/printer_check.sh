#!/bin/bash

cat $OPENVR_DIR/tmp/printer_status.txt
