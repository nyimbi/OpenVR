#!/bin/sh
rm -rf /tmp/results
mkdir -p /tmp/results/output
chmod 7777 /tmp/results/ -R