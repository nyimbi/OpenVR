#!/bin/bash
cd `dirname $0`
./instant_backup.sh $*
