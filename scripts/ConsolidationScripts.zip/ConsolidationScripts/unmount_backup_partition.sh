#!/bin/bash
echo "password" | sudo -S umount $1
sleep 5;
echo "password" | sudo -S umount $1
