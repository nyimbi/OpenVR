#!/bin/sh
cd /opt/openvr
tar -cf $1/stored_minutiae.tar stored_minutiae
