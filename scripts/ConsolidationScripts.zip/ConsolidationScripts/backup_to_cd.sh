#!/bin/bash

cdrecord -eject -data  ~/.zinstant/instant_backup.iso
