#!/bin/sh
echo `mysqladmin -u root --password=0yVcBpu.Ce3g\$ -P 30311 -h 127.0.0.1 ping`