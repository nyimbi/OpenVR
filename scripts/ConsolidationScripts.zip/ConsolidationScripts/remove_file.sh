#!/bin/sh
rm  "$1/*"
