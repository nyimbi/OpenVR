#!/bin/bash

mkdir -p /opt/.openvr-patches/release
chown -R openvr:openvr /opt/.openvr-patches
cp -r /media/F234-EA08/latest-scripts/* /opt/openvr/scripts/
cd /opt/openvr/scripts
./import_patches.sh
chown -R openvr:openvr /opt/openvr/



