#!/bin/sh
mysqld_safe --defaults-file=/opt_openvr/libd/my.cnf &
