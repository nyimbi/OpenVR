#include "myeventfilter.h"


MyEventFilter::MyEventFilter(QObject *parent) :
    QObject(parent)
{





}


int MyEventFilter::checkLastActivity(){

    return 44;

}
