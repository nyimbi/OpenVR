#include "wait_dialog.h"

wait_dialog::wait_dialog()
{

}
