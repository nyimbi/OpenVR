DROP DATABASE openvr_merging;
