//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TCI.RC
//
#define RESOURCE_H__                    1
#define IDB_BITMAP1                     128


//-------------------------------- Constants --------------------------------
#define REVISION    "TouchChip LIBTCI.SO"

#define RELEASE             9
#define VERSION             1   // need to manually edit MYFILEVERSION
#define VERSION_SUB_SUB     1   // for intermediate releases

// External variant
#if defined(VERSION_LINUX) || defined(VERSION_UNIX)
#define VERSION_SUB         5
#define MYFILEVERSION       "9,1,5,1"   // external static LINUX/UNIX version
#endif

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         137
#define _APS_NEXT_CONTROL_VALUE         1137
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
